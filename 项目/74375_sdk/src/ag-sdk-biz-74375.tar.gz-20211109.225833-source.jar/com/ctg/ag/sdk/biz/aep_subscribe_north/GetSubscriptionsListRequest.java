package com.ctg.ag.sdk.biz.aep_subscribe_north;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetSubscriptionsListRequest extends BaseApiRequest {

    public GetSubscriptionsListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20181031202027"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("subType", ParamPosition.QUERY)
        , new Meta("searchValue", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetSubscriptionsListResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetSubscriptionsListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetSubscriptionsListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetSubscriptionsListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetSubscriptionsListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetSubscriptionsListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetSubscriptionsListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetSubscriptionsListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetSubscriptionsListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamSubType(){
    	return this.getParam("subType");
    }

    public GetSubscriptionsListRequest setParamSubType(Object value){
    	this.setParam("subType", value);
    	return this;
    }
    
    public List<String> getParamsSubType(){
    	return this.getParams("subType");
    }

    public GetSubscriptionsListRequest addParamSubType(Object value){
    	this.addParam("subType", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsSubType(Iterable<?> values){
    	this.addParams("subType", values);
    	return this;
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public GetSubscriptionsListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public GetSubscriptionsListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public GetSubscriptionsListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
}