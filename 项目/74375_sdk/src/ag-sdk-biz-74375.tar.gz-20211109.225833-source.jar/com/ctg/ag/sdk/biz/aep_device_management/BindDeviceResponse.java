package com.ctg.ag.sdk.biz.aep_device_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class BindDeviceResponse extends BaseApiResponse {
}