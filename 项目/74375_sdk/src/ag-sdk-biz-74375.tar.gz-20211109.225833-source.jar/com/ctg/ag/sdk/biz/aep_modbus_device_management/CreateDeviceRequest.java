package com.ctg.ag.sdk.biz.aep_modbus_device_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateDeviceRequest extends BaseApiRequest {

    public CreateDeviceRequest(){
        super(RequestFormat.type("POST", "application/json; charset=UTF-8"), "20200404012437"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new CreateDeviceResponse();
    }
    
}