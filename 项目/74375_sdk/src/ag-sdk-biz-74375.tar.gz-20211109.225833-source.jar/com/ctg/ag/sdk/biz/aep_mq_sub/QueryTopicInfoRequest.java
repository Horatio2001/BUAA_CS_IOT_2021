package com.ctg.ag.sdk.biz.aep_mq_sub;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTopicInfoRequest extends BaseApiRequest {

    public QueryTopicInfoRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201218153403"
        , new Meta("topicId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryTopicInfoResponse();
    }
    
    public String getParamTopicId(){
    	return this.getParam("topicId");
    }

    public QueryTopicInfoRequest setParamTopicId(Object value){
    	this.setParam("topicId", value);
    	return this;
    }
    
    public List<String> getParamsTopicId(){
    	return this.getParams("topicId");
    }

    public QueryTopicInfoRequest addParamTopicId(Object value){
    	this.addParam("topicId", value);
    	return this;
    }
    
    public QueryTopicInfoRequest addParamsTopicId(Iterable<?> values){
    	this.addParams("topicId", values);
    	return this;
    }
    
}