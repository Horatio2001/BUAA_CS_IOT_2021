package com.ctg.ag.sdk.biz.aep_modbus_device_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteDeviceRequest extends BaseApiRequest {

    public DeleteDeviceRequest(){
        super(RequestFormat.type("DELETE", "application/x-www-form-urlencoded; charset=UTF-8"), "20200404012425"
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("deviceIds", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new DeleteDeviceResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public DeleteDeviceRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public DeleteDeviceRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public DeleteDeviceRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public DeleteDeviceRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public DeleteDeviceRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public DeleteDeviceRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamDeviceIds(){
    	return this.getParam("deviceIds");
    }

    public DeleteDeviceRequest setParamDeviceIds(Object value){
    	this.setParam("deviceIds", value);
    	return this;
    }
    
    public List<String> getParamsDeviceIds(){
    	return this.getParams("deviceIds");
    }

    public DeleteDeviceRequest addParamDeviceIds(Object value){
    	this.addParam("deviceIds", value);
    	return this;
    }
    
    public DeleteDeviceRequest addParamsDeviceIds(Iterable<?> values){
    	this.addParams("deviceIds", values);
    	return this;
    }
    
}