package com.ctg.ag.sdk.biz.aep_rule_engine;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetRulesResponse extends BaseApiResponse {
}