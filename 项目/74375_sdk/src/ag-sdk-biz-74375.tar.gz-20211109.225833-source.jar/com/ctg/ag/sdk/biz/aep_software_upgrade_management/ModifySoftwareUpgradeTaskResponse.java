package com.ctg.ag.sdk.biz.aep_software_upgrade_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ModifySoftwareUpgradeTaskResponse extends BaseApiResponse {
}