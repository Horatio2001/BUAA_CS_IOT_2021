package com.ctg.ag.sdk.biz.aep_device_control;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteControlListResponse extends BaseApiResponse {
}