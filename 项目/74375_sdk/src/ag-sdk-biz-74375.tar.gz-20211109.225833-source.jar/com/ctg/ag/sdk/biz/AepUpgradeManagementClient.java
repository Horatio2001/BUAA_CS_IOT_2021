package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeDetailRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeDetailResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.ControlRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.ControlRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpradeDeviceListRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpradeDeviceListResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.DeleteRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.DeleteRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeTaskListRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeTaskListResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.ModifyRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.ModifyRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.CreateRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.CreateRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.OperationalRemoteUpgradeTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.OperationalRemoteUpgradeTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeSubtasksRequest;
import com.ctg.ag.sdk.biz.aep_upgrade_management.QueryRemoteUpgradeSubtasksResponse;

public final class AepUpgradeManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepUpgradeManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepUpgradeManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_upgrade_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_upgrade_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_upgrade_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_upgrade_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepUpgradeManagementClient build(BuilderParams params) {
				return new AepUpgradeManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepUpgradeManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryRemoteUpgradeDetailResponse QueryRemoteUpgradeDetail(QueryRemoteUpgradeDetailRequest request) throws Exception {
		String apiPath = "/detail";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRemoteUpgradeDetailResponse> QueryRemoteUpgradeDetail(QueryRemoteUpgradeDetailRequest request, ApiCallBack<QueryRemoteUpgradeDetailRequest, QueryRemoteUpgradeDetailResponse> callback) {
		String apiPath = "/detail";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryRemoteUpgradeTaskResponse QueryRemoteUpgradeTask(QueryRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/task";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRemoteUpgradeTaskResponse> QueryRemoteUpgradeTask(QueryRemoteUpgradeTaskRequest request, ApiCallBack<QueryRemoteUpgradeTaskRequest, QueryRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/task";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ControlRemoteUpgradeTaskResponse ControlRemoteUpgradeTask(ControlRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/control";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ControlRemoteUpgradeTaskResponse> ControlRemoteUpgradeTask(ControlRemoteUpgradeTaskRequest request, ApiCallBack<ControlRemoteUpgradeTaskRequest, ControlRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/control";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryRemoteUpradeDeviceListResponse QueryRemoteUpradeDeviceList(QueryRemoteUpradeDeviceListRequest request) throws Exception {
		String apiPath = "/devices";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRemoteUpradeDeviceListResponse> QueryRemoteUpradeDeviceList(QueryRemoteUpradeDeviceListRequest request, ApiCallBack<QueryRemoteUpradeDeviceListRequest, QueryRemoteUpradeDeviceListResponse> callback) {
		String apiPath = "/devices";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteRemoteUpgradeTaskResponse DeleteRemoteUpgradeTask(DeleteRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/task";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteRemoteUpgradeTaskResponse> DeleteRemoteUpgradeTask(DeleteRemoteUpgradeTaskRequest request, ApiCallBack<DeleteRemoteUpgradeTaskRequest, DeleteRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/task";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryRemoteUpgradeTaskListResponse QueryRemoteUpgradeTaskList(QueryRemoteUpgradeTaskListRequest request) throws Exception {
		String apiPath = "/tasks";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRemoteUpgradeTaskListResponse> QueryRemoteUpgradeTaskList(QueryRemoteUpgradeTaskListRequest request, ApiCallBack<QueryRemoteUpgradeTaskListRequest, QueryRemoteUpgradeTaskListResponse> callback) {
		String apiPath = "/tasks";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ModifyRemoteUpgradeTaskResponse ModifyRemoteUpgradeTask(ModifyRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/task";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ModifyRemoteUpgradeTaskResponse> ModifyRemoteUpgradeTask(ModifyRemoteUpgradeTaskRequest request, ApiCallBack<ModifyRemoteUpgradeTaskRequest, ModifyRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/task";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateRemoteUpgradeTaskResponse CreateRemoteUpgradeTask(CreateRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/task";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateRemoteUpgradeTaskResponse> CreateRemoteUpgradeTask(CreateRemoteUpgradeTaskRequest request, ApiCallBack<CreateRemoteUpgradeTaskRequest, CreateRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/task";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public OperationalRemoteUpgradeTaskResponse OperationalRemoteUpgradeTask(OperationalRemoteUpgradeTaskRequest request) throws Exception {
		String apiPath = "/operational";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<OperationalRemoteUpgradeTaskResponse> OperationalRemoteUpgradeTask(OperationalRemoteUpgradeTaskRequest request, ApiCallBack<OperationalRemoteUpgradeTaskRequest, OperationalRemoteUpgradeTaskResponse> callback) {
		String apiPath = "/operational";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryRemoteUpgradeSubtasksResponse QueryRemoteUpgradeSubtasks(QueryRemoteUpgradeSubtasksRequest request) throws Exception {
		String apiPath = "/details";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRemoteUpgradeSubtasksResponse> QueryRemoteUpgradeSubtasks(QueryRemoteUpgradeSubtasksRequest request, ApiCallBack<QueryRemoteUpgradeSubtasksRequest, QueryRemoteUpgradeSubtasksResponse> callback) {
		String apiPath = "/details";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}