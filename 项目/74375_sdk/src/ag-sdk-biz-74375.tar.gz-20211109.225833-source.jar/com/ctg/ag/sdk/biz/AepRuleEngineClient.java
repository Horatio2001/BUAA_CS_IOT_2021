package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_rule_engine.SaasCreateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasCreateRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasQueryRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasQueryRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasUpdateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasUpdateRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasDeleteRuleEngineRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.SaasDeleteRuleEngineResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetRulesRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetRulesResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetRuleRunStatusRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetRuleRunStatusResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateRuleRunStatusRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateRuleRunStatusResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateForwardRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateForwardResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateForwardRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateForwardResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteForwardRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteForwardResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetForwardsRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetForwardsResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetWarnsRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetWarnsResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteWarnRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteWarnResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateWarnRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateWarnResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateWarnRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateWarnResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateActionRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.CreateActionResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateActionRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.UpdateActionResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteActionRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.DeleteActionResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetActionsRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetActionsResponse;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetWarnUsersRequest;
import com.ctg.ag.sdk.biz.aep_rule_engine.GetWarnUsersResponse;

public final class AepRuleEngineClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepRuleEngineClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepRuleEngineClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_rule_engine");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_rule_engine");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_rule_engine");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_rule_engine");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepRuleEngineClient build(BuilderParams params) {
				return new AepRuleEngineClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepRuleEngineClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public SaasCreateRuleResponse saasCreateRule(SaasCreateRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/createRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasCreateRuleResponse> saasCreateRule(SaasCreateRuleRequest request, ApiCallBack<SaasCreateRuleRequest, SaasCreateRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/createRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasQueryRuleResponse saasQueryRule(SaasQueryRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/queryRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasQueryRuleResponse> saasQueryRule(SaasQueryRuleRequest request, ApiCallBack<SaasQueryRuleRequest, SaasQueryRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/queryRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasUpdateRuleResponse saasUpdateRule(SaasUpdateRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/updateRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasUpdateRuleResponse> saasUpdateRule(SaasUpdateRuleRequest request, ApiCallBack<SaasUpdateRuleRequest, SaasUpdateRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/updateRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasDeleteRuleEngineResponse saasDeleteRuleEngine(SaasDeleteRuleEngineRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/deleteRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasDeleteRuleEngineResponse> saasDeleteRuleEngine(SaasDeleteRuleEngineRequest request, ApiCallBack<SaasDeleteRuleEngineRequest, SaasDeleteRuleEngineResponse> callback) {
		String apiPath = "/api/v2/rule/sass/deleteRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateRuleResponse CreateRule(CreateRuleRequest request) throws Exception {
		String apiPath = "/v3/rule/createRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateRuleResponse> CreateRule(CreateRuleRequest request, ApiCallBack<CreateRuleRequest, CreateRuleResponse> callback) {
		String apiPath = "/v3/rule/createRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateRuleResponse UpdateRule(UpdateRuleRequest request) throws Exception {
		String apiPath = "/v3/rule/updateRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateRuleResponse> UpdateRule(UpdateRuleRequest request, ApiCallBack<UpdateRuleRequest, UpdateRuleResponse> callback) {
		String apiPath = "/v3/rule/updateRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteRuleResponse DeleteRule(DeleteRuleRequest request) throws Exception {
		String apiPath = "/v3/rule/deleteRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteRuleResponse> DeleteRule(DeleteRuleRequest request, ApiCallBack<DeleteRuleRequest, DeleteRuleResponse> callback) {
		String apiPath = "/v3/rule/deleteRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetRulesResponse GetRules(GetRulesRequest request) throws Exception {
		String apiPath = "/v3/rule/getRules";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetRulesResponse> GetRules(GetRulesRequest request, ApiCallBack<GetRulesRequest, GetRulesResponse> callback) {
		String apiPath = "/v3/rule/getRules";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetRuleRunStatusResponse GetRuleRunStatus(GetRuleRunStatusRequest request) throws Exception {
		String apiPath = "/v3/rule/getRuleRunningStatus";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetRuleRunStatusResponse> GetRuleRunStatus(GetRuleRunStatusRequest request, ApiCallBack<GetRuleRunStatusRequest, GetRuleRunStatusResponse> callback) {
		String apiPath = "/v3/rule/getRuleRunningStatus";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateRuleRunStatusResponse UpdateRuleRunStatus(UpdateRuleRunStatusRequest request) throws Exception {
		String apiPath = "/v3/rule/modifyRuleRunningStatus";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateRuleRunStatusResponse> UpdateRuleRunStatus(UpdateRuleRunStatusRequest request, ApiCallBack<UpdateRuleRunStatusRequest, UpdateRuleRunStatusResponse> callback) {
		String apiPath = "/v3/rule/modifyRuleRunningStatus";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateForwardResponse CreateForward(CreateForwardRequest request) throws Exception {
		String apiPath = "/v3/rule/addForward";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateForwardResponse> CreateForward(CreateForwardRequest request, ApiCallBack<CreateForwardRequest, CreateForwardResponse> callback) {
		String apiPath = "/v3/rule/addForward";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateForwardResponse UpdateForward(UpdateForwardRequest request) throws Exception {
		String apiPath = "/v3/rule/updateForward";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateForwardResponse> UpdateForward(UpdateForwardRequest request, ApiCallBack<UpdateForwardRequest, UpdateForwardResponse> callback) {
		String apiPath = "/v3/rule/updateForward";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteForwardResponse DeleteForward(DeleteForwardRequest request) throws Exception {
		String apiPath = "/v3/rule/deleteForward";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteForwardResponse> DeleteForward(DeleteForwardRequest request, ApiCallBack<DeleteForwardRequest, DeleteForwardResponse> callback) {
		String apiPath = "/v3/rule/deleteForward";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetForwardsResponse GetForwards(GetForwardsRequest request) throws Exception {
		String apiPath = "/v3/rule/getForwards";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetForwardsResponse> GetForwards(GetForwardsRequest request, ApiCallBack<GetForwardsRequest, GetForwardsResponse> callback) {
		String apiPath = "/v3/rule/getForwards";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetWarnsResponse GetWarns(GetWarnsRequest request) throws Exception {
		String apiPath = "/v3/rule/getWarns";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetWarnsResponse> GetWarns(GetWarnsRequest request, ApiCallBack<GetWarnsRequest, GetWarnsResponse> callback) {
		String apiPath = "/v3/rule/getWarns";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteWarnResponse DeleteWarn(DeleteWarnRequest request) throws Exception {
		String apiPath = "/v3/rule/deleteWarn";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteWarnResponse> DeleteWarn(DeleteWarnRequest request, ApiCallBack<DeleteWarnRequest, DeleteWarnResponse> callback) {
		String apiPath = "/v3/rule/deleteWarn";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateWarnResponse UpdateWarn(UpdateWarnRequest request) throws Exception {
		String apiPath = "/v3/rule/updateWarn";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateWarnResponse> UpdateWarn(UpdateWarnRequest request, ApiCallBack<UpdateWarnRequest, UpdateWarnResponse> callback) {
		String apiPath = "/v3/rule/updateWarn";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateWarnResponse CreateWarn(CreateWarnRequest request) throws Exception {
		String apiPath = "/v3/rule/addWarn";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateWarnResponse> CreateWarn(CreateWarnRequest request, ApiCallBack<CreateWarnRequest, CreateWarnResponse> callback) {
		String apiPath = "/v3/rule/addWarn";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateActionResponse CreateAction(CreateActionRequest request) throws Exception {
		String apiPath = "/v3/rule/addAction";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateActionResponse> CreateAction(CreateActionRequest request, ApiCallBack<CreateActionRequest, CreateActionResponse> callback) {
		String apiPath = "/v3/rule/addAction";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateActionResponse UpdateAction(UpdateActionRequest request) throws Exception {
		String apiPath = "/v3/rule/updateAction";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateActionResponse> UpdateAction(UpdateActionRequest request, ApiCallBack<UpdateActionRequest, UpdateActionResponse> callback) {
		String apiPath = "/v3/rule/updateAction";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteActionResponse DeleteAction(DeleteActionRequest request) throws Exception {
		String apiPath = "/v3/rule/deleteAct";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteActionResponse> DeleteAction(DeleteActionRequest request, ApiCallBack<DeleteActionRequest, DeleteActionResponse> callback) {
		String apiPath = "/v3/rule/deleteAct";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetActionsResponse GetActions(GetActionsRequest request) throws Exception {
		String apiPath = "/v3/rule/getActions";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetActionsResponse> GetActions(GetActionsRequest request, ApiCallBack<GetActionsRequest, GetActionsResponse> callback) {
		String apiPath = "/v3/rule/getActions";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetWarnUsersResponse GetWarnUsers(GetWarnUsersRequest request) throws Exception {
		String apiPath = "/v3/rule/getWarnUsers";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetWarnUsersResponse> GetWarnUsers(GetWarnUsersRequest request, ApiCallBack<GetWarnUsersRequest, GetWarnUsersResponse> callback) {
		String apiPath = "/v3/rule/getWarnUsers";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}