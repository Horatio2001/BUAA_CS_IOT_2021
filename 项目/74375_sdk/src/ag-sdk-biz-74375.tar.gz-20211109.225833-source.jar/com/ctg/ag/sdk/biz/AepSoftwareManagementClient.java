package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_software_management.UpdateSoftwareRequest;
import com.ctg.ag.sdk.biz.aep_software_management.UpdateSoftwareResponse;
import com.ctg.ag.sdk.biz.aep_software_management.DeleteSoftwareRequest;
import com.ctg.ag.sdk.biz.aep_software_management.DeleteSoftwareResponse;
import com.ctg.ag.sdk.biz.aep_software_management.QuerySoftwareRequest;
import com.ctg.ag.sdk.biz.aep_software_management.QuerySoftwareResponse;
import com.ctg.ag.sdk.biz.aep_software_management.QuerySoftwareListRequest;
import com.ctg.ag.sdk.biz.aep_software_management.QuerySoftwareListResponse;

public final class AepSoftwareManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepSoftwareManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepSoftwareManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_software_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_software_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_software_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_software_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepSoftwareManagementClient build(BuilderParams params) {
				return new AepSoftwareManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepSoftwareManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public UpdateSoftwareResponse UpdateSoftware(UpdateSoftwareRequest request) throws Exception {
		String apiPath = "/software";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateSoftwareResponse> UpdateSoftware(UpdateSoftwareRequest request, ApiCallBack<UpdateSoftwareRequest, UpdateSoftwareResponse> callback) {
		String apiPath = "/software";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteSoftwareResponse DeleteSoftware(DeleteSoftwareRequest request) throws Exception {
		String apiPath = "/software";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteSoftwareResponse> DeleteSoftware(DeleteSoftwareRequest request, ApiCallBack<DeleteSoftwareRequest, DeleteSoftwareResponse> callback) {
		String apiPath = "/software";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QuerySoftwareResponse QuerySoftware(QuerySoftwareRequest request) throws Exception {
		String apiPath = "/software";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QuerySoftwareResponse> QuerySoftware(QuerySoftwareRequest request, ApiCallBack<QuerySoftwareRequest, QuerySoftwareResponse> callback) {
		String apiPath = "/software";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QuerySoftwareListResponse QuerySoftwareList(QuerySoftwareListRequest request) throws Exception {
		String apiPath = "/softwares";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QuerySoftwareListResponse> QuerySoftwareList(QuerySoftwareListRequest request, ApiCallBack<QuerySoftwareListRequest, QuerySoftwareListResponse> callback) {
		String apiPath = "/softwares";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}