package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_device_group_management.CreateDeviceGroupRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.CreateDeviceGroupResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.UpdateDeviceGroupRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.UpdateDeviceGroupResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.DeleteDeviceGroupRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.DeleteDeviceGroupResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.QueryDeviceGroupListRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.QueryDeviceGroupListResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.QueryGroupDeviceListRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.QueryGroupDeviceListResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.UpdateDeviceGroupRelationRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.UpdateDeviceGroupRelationResponse;
import com.ctg.ag.sdk.biz.aep_device_group_management.GetGroupDetailByDeviceIdRequest;
import com.ctg.ag.sdk.biz.aep_device_group_management.GetGroupDetailByDeviceIdResponse;

public final class AepDeviceGroupManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceGroupManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceGroupManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_device_group_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_device_group_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_device_group_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_device_group_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepDeviceGroupManagementClient build(BuilderParams params) {
				return new AepDeviceGroupManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepDeviceGroupManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public CreateDeviceGroupResponse CreateDeviceGroup(CreateDeviceGroupRequest request) throws Exception {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateDeviceGroupResponse> CreateDeviceGroup(CreateDeviceGroupRequest request, ApiCallBack<CreateDeviceGroupRequest, CreateDeviceGroupResponse> callback) {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateDeviceGroupResponse UpdateDeviceGroup(UpdateDeviceGroupRequest request) throws Exception {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateDeviceGroupResponse> UpdateDeviceGroup(UpdateDeviceGroupRequest request, ApiCallBack<UpdateDeviceGroupRequest, UpdateDeviceGroupResponse> callback) {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteDeviceGroupResponse DeleteDeviceGroup(DeleteDeviceGroupRequest request) throws Exception {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteDeviceGroupResponse> DeleteDeviceGroup(DeleteDeviceGroupRequest request, ApiCallBack<DeleteDeviceGroupRequest, DeleteDeviceGroupResponse> callback) {
		String apiPath = "/deviceGroup";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceGroupListResponse QueryDeviceGroupList(QueryDeviceGroupListRequest request) throws Exception {
		String apiPath = "/deviceGroups";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceGroupListResponse> QueryDeviceGroupList(QueryDeviceGroupListRequest request, ApiCallBack<QueryDeviceGroupListRequest, QueryDeviceGroupListResponse> callback) {
		String apiPath = "/deviceGroups";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryGroupDeviceListResponse QueryGroupDeviceList(QueryGroupDeviceListRequest request) throws Exception {
		String apiPath = "/groupDeviceList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryGroupDeviceListResponse> QueryGroupDeviceList(QueryGroupDeviceListRequest request, ApiCallBack<QueryGroupDeviceListRequest, QueryGroupDeviceListResponse> callback) {
		String apiPath = "/groupDeviceList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateDeviceGroupRelationResponse UpdateDeviceGroupRelation(UpdateDeviceGroupRelationRequest request) throws Exception {
		String apiPath = "/deviceGroupRelation";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateDeviceGroupRelationResponse> UpdateDeviceGroupRelation(UpdateDeviceGroupRelationRequest request, ApiCallBack<UpdateDeviceGroupRelationRequest, UpdateDeviceGroupRelationResponse> callback) {
		String apiPath = "/deviceGroupRelation";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetGroupDetailByDeviceIdResponse getGroupDetailByDeviceId(GetGroupDetailByDeviceIdRequest request) throws Exception {
		String apiPath = "/groupOfDeviceId";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetGroupDetailByDeviceIdResponse> getGroupDetailByDeviceId(GetGroupDetailByDeviceIdRequest request, ApiCallBack<GetGroupDetailByDeviceIdRequest, GetGroupDetailByDeviceIdResponse> callback) {
		String apiPath = "/groupOfDeviceId";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}