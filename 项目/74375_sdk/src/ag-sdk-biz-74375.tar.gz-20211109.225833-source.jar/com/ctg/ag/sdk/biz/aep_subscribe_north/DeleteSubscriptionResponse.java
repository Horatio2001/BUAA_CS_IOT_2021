package com.ctg.ag.sdk.biz.aep_subscribe_north;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteSubscriptionResponse extends BaseApiResponse {
}