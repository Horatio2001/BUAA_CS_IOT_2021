package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_device_model.QueryPropertyListRequest;
import com.ctg.ag.sdk.biz.aep_device_model.QueryPropertyListResponse;
import com.ctg.ag.sdk.biz.aep_device_model.QueryServiceListRequest;
import com.ctg.ag.sdk.biz.aep_device_model.QueryServiceListResponse;

public final class AepDeviceModelClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceModelClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceModelClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_device_model");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_device_model");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_device_model");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_device_model");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepDeviceModelClient build(BuilderParams params) {
				return new AepDeviceModelClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepDeviceModelClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryPropertyListResponse QueryPropertyList(QueryPropertyListRequest request) throws Exception {
		String apiPath = "/dm/app/model/properties";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryPropertyListResponse> QueryPropertyList(QueryPropertyListRequest request, ApiCallBack<QueryPropertyListRequest, QueryPropertyListResponse> callback) {
		String apiPath = "/dm/app/model/properties";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryServiceListResponse QueryServiceList(QueryServiceListRequest request) throws Exception {
		String apiPath = "/dm/app/model/services";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryServiceListResponse> QueryServiceList(QueryServiceListRequest request, ApiCallBack<QueryServiceListRequest, QueryServiceListResponse> callback) {
		String apiPath = "/dm/app/model/services";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}