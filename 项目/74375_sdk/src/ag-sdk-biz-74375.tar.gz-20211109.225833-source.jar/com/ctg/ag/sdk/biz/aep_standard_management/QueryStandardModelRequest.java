package com.ctg.ag.sdk.biz.aep_standard_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryStandardModelRequest extends BaseApiRequest {

    public QueryStandardModelRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190713033424"
        , new Meta("standardVersion", ParamPosition.QUERY)
        , new Meta("thirdType", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryStandardModelResponse();
    }
    
    public String getParamStandardVersion(){
    	return this.getParam("standardVersion");
    }

    public QueryStandardModelRequest setParamStandardVersion(Object value){
    	this.setParam("standardVersion", value);
    	return this;
    }
    
    public List<String> getParamsStandardVersion(){
    	return this.getParams("standardVersion");
    }

    public QueryStandardModelRequest addParamStandardVersion(Object value){
    	this.addParam("standardVersion", value);
    	return this;
    }
    
    public QueryStandardModelRequest addParamsStandardVersion(Iterable<?> values){
    	this.addParams("standardVersion", values);
    	return this;
    }
    
    public String getParamThirdType(){
    	return this.getParam("thirdType");
    }

    public QueryStandardModelRequest setParamThirdType(Object value){
    	this.setParam("thirdType", value);
    	return this;
    }
    
    public List<String> getParamsThirdType(){
    	return this.getParams("thirdType");
    }

    public QueryStandardModelRequest addParamThirdType(Object value){
    	this.addParam("thirdType", value);
    	return this;
    }
    
    public QueryStandardModelRequest addParamsThirdType(Iterable<?> values){
    	this.addParams("thirdType", values);
    	return this;
    }
    
}