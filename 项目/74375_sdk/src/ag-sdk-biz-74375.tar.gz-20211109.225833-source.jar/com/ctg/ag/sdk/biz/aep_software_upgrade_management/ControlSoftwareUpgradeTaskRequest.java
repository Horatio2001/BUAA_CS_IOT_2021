package com.ctg.ag.sdk.biz.aep_software_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ControlSoftwareUpgradeTaskRequest extends BaseApiRequest {

    public ControlSoftwareUpgradeTaskRequest(){
        super(RequestFormat.type("PUT", "application/json; charset=UTF-8"), "20200529233046"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new ControlSoftwareUpgradeTaskResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public ControlSoftwareUpgradeTaskRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public ControlSoftwareUpgradeTaskRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public ControlSoftwareUpgradeTaskRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public ControlSoftwareUpgradeTaskRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public ControlSoftwareUpgradeTaskRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public ControlSoftwareUpgradeTaskRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}