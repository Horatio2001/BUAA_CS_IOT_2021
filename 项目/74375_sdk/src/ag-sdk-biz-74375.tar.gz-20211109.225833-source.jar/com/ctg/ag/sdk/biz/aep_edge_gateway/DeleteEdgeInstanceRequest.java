package com.ctg.ag.sdk.biz.aep_edge_gateway;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteEdgeInstanceRequest extends BaseApiRequest {

    public DeleteEdgeInstanceRequest(){
        super(RequestFormat.type("DELETE", "application/x-www-form-urlencoded; charset=UTF-8"), "20201225235957"
        , new Meta("id", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new DeleteEdgeInstanceResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public DeleteEdgeInstanceRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public DeleteEdgeInstanceRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public DeleteEdgeInstanceRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
}