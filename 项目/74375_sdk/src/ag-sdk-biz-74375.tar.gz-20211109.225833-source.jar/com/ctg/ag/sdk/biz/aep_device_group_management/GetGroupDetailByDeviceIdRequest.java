package com.ctg.ag.sdk.biz.aep_device_group_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetGroupDetailByDeviceIdRequest extends BaseApiRequest {

    public GetGroupDetailByDeviceIdRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20211014095939"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("deviceId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetGroupDetailByDeviceIdResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetGroupDetailByDeviceIdRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetGroupDetailByDeviceIdRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetGroupDetailByDeviceIdRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public GetGroupDetailByDeviceIdRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public GetGroupDetailByDeviceIdRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public GetGroupDetailByDeviceIdRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
}