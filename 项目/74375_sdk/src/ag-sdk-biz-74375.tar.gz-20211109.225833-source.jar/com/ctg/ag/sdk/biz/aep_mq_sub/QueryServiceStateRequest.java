package com.ctg.ag.sdk.biz.aep_mq_sub;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryServiceStateRequest extends BaseApiRequest {

    public QueryServiceStateRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201218144210"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryServiceStateResponse();
    }
    
}