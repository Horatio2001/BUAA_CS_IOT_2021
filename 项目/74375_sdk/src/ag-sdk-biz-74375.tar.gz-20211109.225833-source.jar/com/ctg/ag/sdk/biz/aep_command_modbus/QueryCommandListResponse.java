package com.ctg.ag.sdk.biz.aep_command_modbus;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryCommandListResponse extends BaseApiResponse {
}