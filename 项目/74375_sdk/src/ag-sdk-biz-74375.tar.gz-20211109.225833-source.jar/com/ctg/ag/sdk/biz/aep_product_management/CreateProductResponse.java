package com.ctg.ag.sdk.biz.aep_product_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateProductResponse extends BaseApiResponse {
}